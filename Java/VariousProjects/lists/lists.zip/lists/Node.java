


public class Node {

	private String element;
	private Node next;


	public Node(String e, Node n) {
		element = e;
		next = n;
	}
	public Node(String e) {
		element = e;
		next = null;
	}

	public String getElement() {
		return element;
	}

	public Node getNext() {
		return next;
	}

	public void setElement(String e) {
		element = e;
	}

	public void setNext(Node n) {
		next = n;
	}
	
}
