

public class DNode {

	protected ________ element;
	protected ________ next, prev;

	
	public DNode(String e, DNode p, DNode n) {
		element = ____;
		next = ____;
		prev = ____;
	}

	public DNode(String e) {
		element = _____;
		next = ______;
		prev = ______;
	}
	
	public String getElement() {

		_____________;

	}

	public DNode getPrev() {

		______________;

	}


	public DNode getNext() {

		________________;

	}


	public void setElement(String s) {
		_______________;
	}
	
	
	public void setPrev(DNode p) {
		
		_______________;
		
	}
	
	
	public void setNext(DNode n) {
		
		_______________;
		
	}

	

}

