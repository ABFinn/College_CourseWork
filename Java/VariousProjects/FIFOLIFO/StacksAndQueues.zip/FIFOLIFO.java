//driver class  - FIFOLIFO
import java.util.Scanner;
import java.io.*;


public class FIFOLIFO {

   public static void main(String [] args) throws Exception {
   
      Stack <Integer> lifo = new ListStack <Integer> ();
      Queue <Integer> fifo = new ListQueue <Integer> ();
      int lifoProfit = 0;
      int fifoProfit = 0;
      
      //ask the user for the inventory file name
      
      //open up the file using a Scanner
      Scanner file = new Scanner(new File(/* whatever file name they typed */);
      
      //for each line in the file
      
      //while file has next (line)
      
         //read the next line (using nextLine() method)
         String s = file.nextLine();
         
         //create a Scanner based on line
         Scanner line = new Scanner(s);  //say s = "B:10:5"
         line.useDelimiter(":");
         
         //extract the record type, storing it in a String  (use next()
         //extract the number of units (use nextInt())
         //extract the price (use nextInt())
         
         //if record type is "B"
            //loop number of units times
               //enqueue price into fifo
               //push price onto lifo
               
         //if record type is "S"
            //loop number of units times
               //queue
               //dequeue element from queue, subtracting that number from price
               fifoProfit = fifoProfit + (price - fifo.dequeue());
            
         
         
      //end file loop
      
      //output to user the different profits (fifoProfit and lifoProfit)
      
   
   }

}