public class EulerProjects{
   public static void main(String [] args) {
   
      //System.out.println(euler1(1000));
      System.out.println(isPrime(103));
      //System.out.println(euler2(4000000));
      System.out.println(euler3(13195));
   
   }
   public static int euler1(int limit) {
      
      int sum = 0;
      int num = 3;
      while(num < limit){
         if(num % 3 == 0 || num % 5 == 0){
            sum = sum + num;
         }
      num++;
      }
      return sum;
   }
   public static boolean isPrime(long n){
      
      
      if(n == 2){
         return true;
      }
      if(n % 2 == 0) {
         return false;
      }
      
      long factor = 3;
      
      while(factor <= Math.sqrt(n)){
         //if factor is a factor of n
         if(n % factor == 0){
            return false;      
         }
         factor = factor + 2;
        }
       return true;
   
   }
   public static long euler2(int limit){
   
      //create an accumulator variable
      long sum = 0;
      int fib1 = 1;
      int fib2 = 2;
      
      while (fib2 < limit){
         if(fib2 % 2 == 0){
            sum += fib2; //sum = sum + fib
         }
         fib2 += fib1;
         fib1 = fib2 - fib1;
         
      }
      
      
      return sum;
   }
   public static long euler3(long limit){      
      long i = 2;
      
      
      while(!isPrime(limit)){
         while(limit % i != 0 && !isPrime(i)){
            i++;
         } 
         limit = limit/i;
        }               
      return limit;
         
      
   }

}